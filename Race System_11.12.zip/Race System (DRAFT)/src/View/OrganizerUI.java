package View;

public class OrganizerUI {
    public void displayOptions(){

    }
    public void createRace(){

    }
    public void enterResults(){

    }
}
