package View;

public class RacerUI {
    public void displayOptions(){

    }
    public void buyLicense(){

    }
    public void raceSignUp(){

    }
}
