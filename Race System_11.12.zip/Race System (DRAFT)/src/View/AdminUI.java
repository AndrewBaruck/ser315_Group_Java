package View;

public class AdminUI {
    public void displayMenu(){

    }
    public void manageSystem(){

    }
}
