package Controller;

import Model.Organizer;
import Model.Race;

import java.util.ArrayList;

public class RaceController {
    private ArrayList<Race> races;
    private ArrayList<Organizer> organizers;

    public void createRaces(){

    }
    public void enterResults(){

    }
    public ArrayList<Race> getRaces(){
        return races;
    }
    public ArrayList<Race> racesByType(){
        return races;
    }
    public void getResults(Race race){

    }
}
