package Controller;

import Model.License;
import Model.Racer;

import java.util.ArrayList;

public class RacerController {
    private ArrayList<Racer> racers;
    private ArrayList<License> licenses;

    public void registerRacer(){
        //racers.add(racer);
    }
    public void purchaseLicence(){

    }
    public void raceSignUp(){

    }
    public void updateCAT(Racer racer){

    }
}
