package Model;

import java.time.LocalDate;

public class License {

    private int ID;
    private int category;
    private LocalDate creationDate;
    private LocalDate expirationDate;

    public void createLicence(String name, CreditCard card){

    }
    public void deleteLicense(){

    }
    public boolean isValid(){
        return false;
    }
}
