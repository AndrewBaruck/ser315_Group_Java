package Model;

import java.time.LocalDate;

public class CreditCard {
    private int number;
    private LocalDate expiryDate;
    private String name;
    private String billingAddress;

    private Racer racer;
}
