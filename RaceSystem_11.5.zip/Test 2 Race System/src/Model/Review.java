package Model;

public class Review {

    private int rating;
    private String feedback;

    public void editReview(){

    }
}
